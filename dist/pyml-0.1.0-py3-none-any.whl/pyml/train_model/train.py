def train_dummy():
    return "hi"